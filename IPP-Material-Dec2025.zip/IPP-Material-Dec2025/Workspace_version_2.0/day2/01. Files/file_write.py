
helloFile = open("hello2.txt", "w")
helloFile.write("I am teaching in RP today")
helloFile.close()

'''
# reopen to display content
helloFile = open("hello.txt")
print(helloFile.read())
helloFile.close()
 
# open the file for adding next text
helloFile = open("hello.txt", "a")
helloFile.write("Hello world again\n")
helloFile.close()

# reopen to display content
helloFile = open("hello.txt")
print(helloFile.read())
helloFile.close()
'''