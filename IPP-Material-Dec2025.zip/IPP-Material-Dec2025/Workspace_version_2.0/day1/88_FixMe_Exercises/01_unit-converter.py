centimeter = 350
meter = centimeter / FIX_ME

print (str(centimeter) + " centimeter in meter is: " + FIX_ME + " meter.")